The biggest thing in this one was the tabs that were not correct so it wouldn't even run, i had to fix that in order to run it even though you told us not to.
The getArea() returns 0 when the radius is 2 which isn't right.
When you put in text to the radius it crashes.
When you put in text to circle it changes radius to 0.
Also when you put in -10 it becomes radius 0.
You cant ut a boolian for circle it acts weird.
Lastly the constructor is inconsistent.