import random


# Each room is connected to exactly three other rooms.
BURROW = {
    1: [2, 5, 8],
    2: [1, 3, 10],
    3: [2, 4, 12],
    4: [3, 5, 14],
    5: [1, 4, 6],
    6: [5, 7, 15],
    7: [6, 8, 17],
    8: [1, 7, 9],
    9: [8, 10, 18],
    10: [2, 9, 11],
    11: [10, 12, 19],
    12: [3, 11, 13],
    13: [12, 14, 20],
    14: [4, 13, 15],
    15: [6, 14, 16],
    16: [15, 17, 20],
    17: [7, 16, 18],
    18: [9, 17, 19],
    19: [11, 18, 20],
    20: [13, 16, 19],
}


def create_game(random_source=random):
    """Create and return a new game."""
    rooms = list(BURROW.keys())
    locations = random_source.sample(rooms, 6)

    game = {
        "player": locations[0],
        "squirrel": locations[1],
        "pits": [locations[2], locations[3]],
        "bats": [locations[4], locations[5]],
        "arrows": 5,
        "status": "playing",
        "message": "",
    }

    return game


def connected_rooms(room):
    """Return the rooms connected to a room."""
    return BURROW[room]


def is_valid_move(current_room, destination):
    """Return True when the destination is connected to the current room."""
    return destination in connected_rooms(current_room)


def get_warnings(game):
    """Return a list of warnings for hazards in neighboring rooms."""
    warnings = []
    nearby_rooms = connected_rooms(game["player"])

    if game["squirrel"] in nearby_rooms:
        warnings.append("You smell wet squirrel.")

    if any(room in nearby_rooms for room in game["pits"]):
        warnings.append("You feel a cold draft.")

    if any(room in nearby_rooms for room in game["bats"]):
        warnings.append("You hear wings.")

    return warnings


def move_player(game, destination, random_source=random):
    """Move the player and resolve anything in the destination room."""
    if game["status"] != "playing":
        return False

    if not is_valid_move(game["player"], destination):
        game["message"] = "There is no tunnel to that room."
        return False

    game["player"] = destination
    resolve_player_room(game, random_source)
    return True


def resolve_player_room(game, random_source=random):
    """Resolve the hazard, if any, in the player's room."""
    while game["status"] == "playing":
        if game["player"] == game["squirrel"]:
            game["status"] = "lost"
            game["message"] = "The Were-Squirrel attacks you."
            return

        if game["player"] in game["pits"]:
            game["status"] = "lost"
            game["message"] = "You fall into a bottomless pit."
            return

        if game["player"] in game["bats"]:
            new_room = random_source.choice(list(BURROW.keys()))
            game["player"] = new_room
            game["message"] = "Giant bats carry you to room " + str(new_room) + "."
            continue

        game["message"] = "You enter room " + str(game["player"]) + "."
        return


def validate_arrow_path(path):
    """Return True when an arrow path contains one to five valid rooms."""
    if len(path) < 1 or len(path) > 5:
        return False

    for room in path:
        if room not in BURROW:
            return False

    return True


def choose_arrow_room(current_room, requested_room, random_source=random):
    """Return the next room entered by an arrow."""
    if is_valid_move(current_room, requested_room):
        return requested_room

    return random_source.choice(connected_rooms(current_room))


def shoot_arrow(game, path, random_source=random):
    """Fire one arrow along a path and resolve the result."""
    if game["status"] != "playing":
        return False

    if not validate_arrow_path(path):
        game["message"] = "An arrow path must contain one to five valid rooms."
        return False

    game["arrows"] = game["arrows"] - 1
    arrow_room = game["player"]

    for requested_room in path:
        arrow_room = choose_arrow_room(
            arrow_room,
            requested_room,
            random_source,
        )

        if arrow_room == game["squirrel"]:
            game["status"] = "won"
            game["message"] = "You shoot the Were-Squirrel. You win!"
            return True

        if arrow_room == game["player"]:
            game["status"] = "lost"
            game["message"] = "The arrow returns to your room. You shoot yourself."
            return True

    if game["arrows"] == 0:
        game["status"] = "lost"
        game["message"] = "You have run out of arrows."
        return True

    game["message"] = "Your arrow misses."
    maybe_move_squirrel(game, random_source)
    return True


def maybe_move_squirrel(game, random_source=random):
    """Give the Were-Squirrel a 75 percent chance to move after a miss."""
    wakes_up = random_source.random() < 0.75

    if not wakes_up:
        game["message"] += "\nThe tunnles are quiet."
        return

    game["squirrel"] = random_source.choice(
        connected_rooms(game["squirrel"])
    )

    if game["squirrel"] == game["player"]:
        game["status"] = "lost"
        game["message"] = "The Were-Squirrel wakes up, moves, and attacks you."
    else:
        game["message"] += "\nYou hear the Were-Squirrel moving through the tunnels..." 


def describe_turn(game):

    """Return a short description of the player's current situation."""
    room = game["player"]
    tunnels = connected_rooms(room)

    lines = [
        "",
        "You are in room " + str(room) + ".",
        "Tunnels lead to " + ", ".join(str(number) for number in tunnels) + ".",
    ]

    lines.extend(get_warnings(game))
    lines.append("You have " + str(game["arrows"]) + " arrows.")
    return "\n".join(lines)


def ask_for_action():
    """Ask the player whether to move or shoot."""
    while True:
        action = input("Move or shoot? ").strip().lower()

        if action in ["move", "m"]:
            return "move"

        if action in ["shoot", "s"]:
            return "shoot"

        if action in ["h","H","help","?","i"]:
            print_instructions()
        else:
            print("Please enter move or shoot.")


def ask_for_room(prompt):
    """Ask for a room number."""
    while True:
        text = input(prompt).strip()

        if text.isdigit():
            room = int(text)
            if room in BURROW:
                return room

        print("Please enter a room number from 1 to 20.")


def ask_for_arrow_path():
    """Ask for a space-separated arrow path."""
    while True:
        text = input("Arrow path (one to five rooms, separated by spaces): ").strip()
        pieces = text.split()

        if all(piece.isdigit() for piece in pieces):
            path = [int(piece) for piece in pieces]
            if validate_arrow_path(path):
                return path

        print("Enter one to five room numbers separated by spaces.")


def play_game():
    """Run the command-line game."""
    game = create_game()

    print("Hunt the Were-Squirrel")
    print("Find the Were-Squirrel before it finds you.")

    while game["status"] == "playing":
        print(describe_turn(game))
        action = ask_for_action()

        if action == "move":
            destination = ask_for_room("Move to room: ")
            move_player(game, destination)
        else:
            path = ask_for_arrow_path()
            shoot_arrow(game, path)

        print(game["message"])

    if game["status"] == "won":
        print("You survived the hunt.")
    else:
        print("Game over.")

def print_instructions():
    """Print the game instructions."""
    print()
    print("Your goal is to find and shoot the Were-Squirrel.")
    print()
    print("Move through the burrow and pay attention to the warnings:")
    print("- A smell means the Were-Squirrel is in a connected room.")
    print("- A cold draft means a pit is in a connected room.")
    print("- The sound of wings means giant bats are in a connected room.")
    print()
    print("On each turn, you may move or shoot.")
    print("You may move only to a connected room.")
    print()
    print("If you move into the room with the Were-Squirrel, you die.")
    print("If you move into a room with a pit, you die.")
    print("If you move into a room with the giant bats, you are transported to another room.")
    print("The room might be safe, and it might not.")
    print()
    print("You have five arrows.")
    print("An arrow can travel through one to five rooms.")
    print("Enter its path as room numbers separated by spaces.")
    print("For example, '4 3 12' shoots through rooms 4, 3, and 12.")
    print("Each room in the path should connect to the room before it.")
    print("If a room is not connected, the arrow takes a random valid tunnel.")
    print("A wandering arrow can return to your room and hit you.")
    print()
    print("The burrow does not change, so learning its tunnels can help you.")
    print("Avoid the hazards, follow the clues, and shoot carefully.")
    print()


if __name__ == "__main__":
    play_game()
