﻿import pytest
import math
from circle import Circle

# check to see if radius is stored
def test_init():
    c = Circle(5)
    assert c.getRadius() == 5

# negative radius becomes 0
def test_init_negative():
    c = Circle(-10)
    assert c.getRadius() == 0

# non number radius becomes 0
def test_init_bad_type():
    c = Circle("not a number")
    assert c.getRadius() == 0

# getRadius just returns what was set
def test_get_radius():
    c = Circle(7)
    assert c.getRadius() == 7

# setRadius with a value updates and returns True
def test_set_radius():
    c = Circle(1)
    result = c.setRadius(9)
    assert result is True
    assert c.getRadius() == 9

# setRadius w/ negitive old value kept
def test_radius_negative():
    c = Circle(4)
    result = c.setRadius(-3)
    assert result is False
    assert c.getRadius() == 4

# set radius crashes
def test_radius_bad_type():
    c = Circle(4)
    with pytest.raises(TypeError):
        c.setRadius("not a number")

# radius 0 gives area 0
def test_zero():
    c = Circle(0)
    assert c.getArea() == 0

# positive radius gives a positive area
def test_positive():
    c = Circle(3)
    assert c.getArea() > 0

# radius gives 2 when it shouldn't
def test_bug():
    c = Circle(2)
    assert c.getArea() == 0

# radius 0 gives circumference 0
def test_circumference_zero():
    c = Circle(0)
    assert c.getCircumference() == 0

# positive radius gives a positive circumference
def test_circumference_positive():
    c = Circle(3)
    assert c.getCircumference() > 0


