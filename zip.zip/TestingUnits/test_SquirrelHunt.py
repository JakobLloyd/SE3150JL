#squirrel game unittest
import unittest
import SquirrelHunt as sh


def make_game(player=1, squirrel=10, pits=None, bats=None, arrows=5, status="playing"):
    # just builds a game dict so i dont have to retype this every test
    return {
        "player": player,
        "squirrel": squirrel,
        "pits": pits or [3, 4],
        "bats": bats or [6, 7],
        "arrows": arrows,
        "status": status,
        "message": "",
    }


class TestSquirrelHunt(unittest.TestCase):

    # cant shoot once its already over, thats just not great if you could
    def test_shoot_after_game_over(self):
        game = make_game(player=1, status="won")
        result = sh.shoot_arrow(game, [2])
        self.assertFalse(result)

    # 20 rooms total, thats the whole burrow
    def test_burrow_size(self):
        self.assertEqual(len(sh.BURROW), 20)

    # if you shoot the squirrel directly you should just win
    def test_shoot_hit_squirrel(self):
        game = make_game(player=1, squirrel=2)
        sh.shoot_arrow(game, [2])
        self.assertEqual(game["status"], "won")

    # every room should connect to 3 others
    def test_room_connections(self):
        for room, neighbors in sh.BURROW.items():
            self.assertEqual(len(neighbors), 3)

    # walking into a pit better end your game, thats the whole point of a pit
    def test_move_into_pit(self):
        game = make_game(player=1, squirrel=10, pits=[2, 20])
        sh.move_player(game, 2)
        self.assertEqual(game["status"], "lost")

    # if arrows go to 999 or some fake room that shouldnt work
    def test_path_invalid_room(self):
        self.assertFalse(sh.validate_arrow_path([999]))

    # shooting shouldnt just teleport you through rooms that arent even connected
    def test_move_blocked(self):
        game = make_game(player=1)
        result = sh.move_player(game, 20)
        self.assertFalse(result)
        self.assertEqual(game["player"], 1)

    # game shouldnt spawn you standing right next to the squirrel with no warning at all
    def test_new_game_distinct(self):
        game = sh.create_game()
        locations = [game["player"], game["squirrel"], *game["pits"], *game["bats"]]
        self.assertEqual(len(locations), len(set(locations)))

    # an empty path shouldnt count as a real shot
    def test_path_too_short(self):
        self.assertFalse(sh.validate_arrow_path([]))

    # if the squirrels next door you should get a smell warning, makes sense
    def test_warning_squirrel(self):
        game = make_game(player=1, squirrel=2)
        self.assertIn("You smell wet squirrel.", sh.get_warnings(game))

    # every connection should go both directions, one way tunnels would be weird
    def test_connections_symmetric(self):
        self.assertIn(1, sh.BURROW[2])
        self.assertIn(2, sh.BURROW[1])

    # game shouldnt let you move once youve already lost or won
    def test_move_after_game_over(self):
        game = make_game(player=1, status="lost")
        result = sh.move_player(game, 2)
        self.assertFalse(result)

    # you start with 5 arrows every time, thats the rule
    def test_new_game_arrows(self):
        game = sh.create_game()
        self.assertEqual(game["arrows"], 5)

    # bats nearby should give you the wing warning
    def test_warning_bats(self):
        game = make_game(player=1, bats=[8])
        self.assertIn("You hear wings.", sh.get_warnings(game))

    # 6 rooms in a path is too many, max is 5
    def test_path_too_long(self):
        self.assertFalse(sh.validate_arrow_path([1, 2, 3, 4, 5, 6]))

    # walking somewhere adjacent and empty should just work no drama
    def test_move_success(self):
        game = make_game(player=1, squirrel=10, pits=[19, 20], bats=[17, 18])
        sh.move_player(game, 2)
        self.assertEqual(game["player"], 2)
        self.assertEqual(game["status"], "playing")

    # firing an arrow should actually cost you an arrow, obviously
    def test_shoot_decrements_arrows(self):
        game = make_game(player=1, squirrel=10, pits=[19, 20], bats=[17, 18])
        sh.shoot_arrow(game, [2])
        self.assertEqual(game["arrows"], 4)

    # a pit close by should give the cold draft warning
    def test_warning_pit(self):
        game = make_game(player=1, pits=[5])
        self.assertIn("You feel a cold draft.", sh.get_warnings(game))

    # a room cant connect to itself, that would be pointless
    def test_no_self_loop(self):
        for room, neighbors in sh.BURROW.items():
            self.assertNotIn(room, neighbors)

    # if a room is actually connected, going there should be a valid move
    def test_valid_move_true(self):
        self.assertTrue(sh.is_valid_move(1, 2))

    # new game should say youre still playing, not already dead lol
    def test_new_game_status(self):
        game = sh.create_game()
        self.assertEqual(game["status"], "playing")

    # nothing nearby means no warnings, dont scare the player for no reason
    def test_warning_none(self):
        game = make_game(player=1, squirrel=10, pits=[19, 20], bats=[17, 18])
        self.assertEqual(sh.get_warnings(game), [])

    # walking into bats better not crash or send you somewhere that doesnt exist
    def test_move_into_bats(self):
        game = make_game(player=1, squirrel=10, pits=[19, 20], bats=[2, 17])
        sh.move_player(game, 2)
        self.assertIn(game["player"], sh.BURROW)

    # a room that isnt even connected shouldnt count as a valid move
    def test_valid_move_false(self):
        self.assertFalse(sh.is_valid_move(1, 20))

    # walking straight into the squirrel should kill you, no mercy
    def test_move_into_squirrel(self):
        game = make_game(player=1, squirrel=2)
        sh.move_player(game, 2)
        self.assertEqual(game["status"], "lost")

    # 1 room path should still count, its the minimum
    def test_path_min_length(self):
        self.assertTrue(sh.validate_arrow_path([5]))

    # if you request a room that isnt connected the arrow should still land somewhere real
    def test_arrow_room_wander(self):
        result = sh.choose_arrow_room(1, 999)
        self.assertIn(result, sh.connected_rooms(1))

    # game shouldnt just quietly eat your arrow if the shot was invalid
    def test_shoot_invalid_path(self):
        game = make_game(player=1, arrows=5)
        sh.shoot_arrow(game, [])
        self.assertEqual(game["arrows"], 5)

    # missing on your last arrow should end the game, no more chances
    def test_shoot_last_arrow_miss(self):
        game = make_game(player=1, squirrel=10, arrows=1)
        sh.shoot_arrow(game, [2])
        self.assertEqual(game["status"], "lost")

    # 5 rooms should be fine, thats the max path length
    def test_path_max_length(self):
        self.assertTrue(sh.validate_arrow_path([1, 2, 3, 4, 5]))

    # connected_rooms should give back the actual neighbors, not random stuff
    def test_connected_rooms(self):
        self.assertEqual(sh.connected_rooms(1), [2, 5, 8])

    # if the squirrel wakes up and moves it better still be in a real room after
    def test_squirrel_stays_in_valid_room(self):
        game = make_game(player=1, squirrel=10)
        sh.maybe_move_squirrel(game)
        self.assertIn(game["squirrel"], sh.BURROW)

    # if you request a room thats actually connected it should just go there
    def test_arrow_room_direct(self):
        result = sh.choose_arrow_room(1, 2)
        self.assertEqual(result, 2)

    # the turn description should actually tell you what room youre in
    def test_describe_turn_contains_room(self):
        game = make_game(player=1, squirrel=10, pits=[19, 20], bats=[17, 18])
        self.assertIn("room 1", sh.describe_turn(game))

    # it should also tell you how many arrows you have left
    def test_describe_turn_contains_arrows(self):
        game = make_game(player=1, squirrel=10, pits=[19, 20], bats=[17, 18], arrows=3)
        self.assertIn("3 arrows", sh.describe_turn(game))

if __name__ == "__main__":
    unittest.main()